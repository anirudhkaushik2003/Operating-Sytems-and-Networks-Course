#ifndef CD_H
#define CD_H

#include "../globals.h"
#include "../utils/string.h"
#include <stdio.h>
#include <stdlib.h>

void changedir(char *path_name, char *root);

#endif