#ifndef ECHO_H
#define ECHO_H

#include <stdio.h>
#include "../utils/string.h"
#include "../globals.h"
#include "../utils/token_mat.h"

void echo_out(token_mat input);

#endif