#ifndef JOBS_H
#define JOBS_H

#include "../globals.h"
#include "../utils/string.h"
#include "../utils/token_mat.h"
#include "../commands/exec.h"

void printJobs(token_mat args_mat);

#endif