#ifndef REPEAT_H
#define REPEAT_H

#include "../processor/tokenizer.h"
#include "../utils/string.h"
#include "../utils/token_mat.h"


void Repeat(token_mat args_mat);

#endif