#ifndef REPLAY_H
#define REPLAY_H

#include "../globals.h"
#include "../utils/string.h"
#include "../utils/token_mat.h"

void replay(token_mat args_mat,string root);

#endif