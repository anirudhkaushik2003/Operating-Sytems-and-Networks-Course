#ifndef PARSER_H
#define PARSER_H

#include <stdio.h>
#include <string.h>
#include "../globals.h"
#include "../utils/string.h"

string *parse_info(char *input1, int len1);
string *parse_token();



#endif