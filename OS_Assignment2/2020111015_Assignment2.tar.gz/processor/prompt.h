#ifndef PROMPT_H
#define PROMPT_H

#include <stdio.h>
#include <sys/utsname.h>
#include <unistd.h>
#include "../globals.h"
#include "../utils/string.h"



void prompt(string root);
#endif